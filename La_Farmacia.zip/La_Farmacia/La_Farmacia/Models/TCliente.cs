﻿using System;
using System.Collections.Generic;

namespace La_Farmacia.Models
{
    public partial class TCliente
    {
        public TCliente()
        {
            TFactura = new HashSet<TFactura>();
        }

        public int IdCliente { get; set; }
        public string Identificacion { get; set; } = null!;
        public string NombreCliente { get; set; } = null!;
        public string Apellido { get; set; } = null!;
        public string Correo { get; set; } = null!;

        public virtual ICollection<TFactura> TFactura { get; set; }
    }
}
